'''https://pillow.readthedocs.io/en/stable/handbook/tutorial.html'''
'''https://note.nkmk.me/en/python-pillow-composite/'''

# pip install Pillow
from PIL import ImageColor, Image, ImageDraw, ImageFilter

# RGB is a type color space that represents amount of Red, Green, Blue and A -> transparency amount of opaque

print(ImageColor.getcolor('red', 'RGBA'))
print(ImageColor.getcolor('lime', 'RGB'))
print(ImageColor.getcolor('green', 'RGBA'))
(Image.new('RGBA', (500,500), 'lime')).show()
(Image.new('RGBA', (500,500), 'green')).show()
(Image.new('RGB', (500,500), 'green')).show()

im = Image.open('./lena.jpg')
# reading a pixel data
im.getpixel((0,0)) 
# getting image information, format, dimension
im.format
im.format_description
print(im.format, im.width, im.height, im.size, im.mode)
# default set to 75 (1 - 95%)
im.save('./lena10.jpg', quality=10) 
im.save('cropped10.jpg', quality=10)
im.save('cropped30.jpg', quality=30)
im.save('cropped60.jpg', quality=60)
im.save('cropped100.jpg', quality=100)

# -- let's try transparancy, PNG format
im.show()
ima = im.copy()
ima.show()
ima.putalpha(128)
ima.show()

# -- let's now composite 2 images with transparency control
# let's look at the composite method
# image 1 + image 2 + mask image(-> blending weight)

help(Image.composite)
im1 = Image.open('./megryan.jpg')
im2 = Image.open('./seattle.jpg').resize(im1.size)
# https://pillow.readthedocs.io/en/stable/handbook/concepts.html#concept-modes
mask = Image.new("L", im1.size, 128) # 'L'=8-bit pixels, black and white
imcomp = Image.composite(im1, im2, mask)
Image.blend(im1, im2, 0.5)

import numpy
for i in numpy.arange(0, 1, 0.1):
    img = Image.blend(im1, im2, i)
    img.show()

# -- Let's add some shape to it
mask = Image.new("L", im1.size, 0) # 
# The ImageDraw module provide simple 2D graphics for Image objects. 
# You can use this module to create new images, annotate or retouch 
# existing images, and to generate graphics on the fly for web use.
draw = ImageDraw.Draw(mask)
draw.ellipse((180, 26, 320, 173), fill=255) # [(x0, y0, x1, y1]
# composite thru mask image (weight factor per pixel)
im = Image.composite(im1, im2, mask) # im = im1 * mask + im2
im.show() # composite

# -- we can now use a blurred border to make 'high quality' image
mask_blur = mask.filter(ImageFilter.GaussianBlur(20))
mask_blur.show()
im = Image.composite(im1, im2, mask_blur)
im.show()


# # - Let's now crop and create a sub-image
# #   And save to a different image format 
# im = Image.open('zophie.png') 
# # a quick way to see an image on the disk Image.open('zophie.png').show()
# im.format
# im.format_description
# print(im.format, im.width, im.height, im.size, im.mode)
# box = (340,338,568,579)
# # Verify the cropped image
# im.crop(box).show()
# im_crop = im.crop(box)
# # Save it to different format
# im_crop.save('cropped.png')
# im_crop.save('cropped.ppm')
# im_crop.save('cropped.bmp')
# im_crop.save('cropped.gif')

# # Lets resize the input image by half
# # the following statement will display half of width and height
# new_size = tuple(size/2 for size in im.size)
# # usage: thumbnail(size, resample=3) requested size, resample = OPTIONAL BILINEAR, BICUBIC, NEAREST
# # the method modifies the image itself (watch out for artifacts)
# im.thumbnail(new_size) 
# im.save('thumb.jpeg')

# # - how about I am going to crop out and create a subimage, then
# #   paste into a certain location
# catIm = Image.open('zophie.png')
# catCopyIm = catIm.copy()
# box = (340,338,568,579)
# catFaceIm = catCopyIm.crop(box)
# # target.paste
# catCopyIm.paste(catFaceIm, (0, 0))
# # at this point, catCopyIm has pasted face image
# catCopyIm.show()


''' Making a tile image and rotation
catIm = Image.open('zophie.png')
box = (340,338,568,579)
catFaceIm = catIm.crop(box)
catImWidth, catImHeight = catIm.size
catFaceImWidth, catFaceImHeight = catFaceIm.size
# Since this paste operation will modify the target image, need a copy.
catCopyImTile = catIm.copy()
i = 0
for x in range(0, catImWidth, catFaceImWidth):
    for y in range(0, catImHeight, catFaceImHeight):
        print(x, y)
        catCopyImTile.paste(catFaceIm, (x, y))
        # catCopyImTile.paste(catFaceIm.rotate(10*i), (x, y))
        i += 1
catCopyImTile.show()    
'''
'''
catIm = Image.open('zophie.png')
box = (0, 0, 200, 200)
# Create the frames
frames = []
x, y = 0, 0
for i in range(0, catIm.width-200, 10):
    new_frame = catIm.crop(box) #create_image_with_ball(400, 400, x, y, 40)
    frames.append(new_frame)
    box = tuple(x+10 for x in box)
# Save into a GIF file that loops forever
frames[0].save('moving_cat.gif', format='GIF', append_images=frames[1:], save_all=True, duration=100, loop=0)
'''


# lab: https://blog.zhaytam.com/2018/08/21/creating-gifs-using-python-pillow/
# crop the cat's face
# paste to a blank image of 500x500
# rotate 20 degrees
# then feed into animated gif routine() to create rotaing cat face image
#
def create_image_with_ball(width, height, ball_x, ball_y, ball_size):
    # create a white background
    img = Image.new('RGB', (width, height), (255, 255, 255))
    draw = ImageDraw.Draw(img)
    # draw.ellipse takes a 4-tuple (x0, y0, x1, y1) where (x0, y0) is the top-left bound of the box
    # and (x1, y1) is the lower-right bound of the box.
    draw.ellipse((ball_x, ball_y, ball_x + ball_size, ball_y + ball_size), fill='yellow')
    return img


# Create the frames
frames = []
x, y = 0, 0
for i in range(10):
    new_frame = create_image_with_ball(400, 400, x, y, 40)
    # new_frame = create_image_with_ball(400, 400, x, y, 400/(i+1)) # 3D effect going away from me trajectory
    frames.append(new_frame)
    x += 20
    y += 20

# Save into a GIF file that loops forever
frames[0].save('moving.gif', format='GIF', append_images=frames[1:], save_all=True, duration=100, loop=0)



